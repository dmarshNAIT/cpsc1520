# Class Fundamentals

Initialize this project with "npm install" in this folder.

Run the project with "npm start"
