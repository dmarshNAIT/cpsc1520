// import bootstrap
import 'bootstrap/dist/css/bootstrap.min.css';
// import our CSS
import '../css/main.css';

// import EVERYTHING from main.js
import './main.js';
// this isn't the standard way to import: it's a bit of a shortcut.
// ideally we should specify exactly what we want to import