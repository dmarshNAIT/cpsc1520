This is a continuation of the dino-park-tycoon example.

Instead of starting with an empty array, this version will load the dinosaurs from a provided file location.

Check out the .js file for your TO DO list.