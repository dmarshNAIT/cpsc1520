This is a bonus example to give you a bit more practice working with arrays, object literals, and a few types of loops. A [sample solution](https://github.com/dmarshNAIT/cpsc1520/tree/main/dino-park-tycoon-complete) is posted.

If you have any questions, need hints, or find any errors, please [let me know](mailto:dmarsh@nait.ca)!
