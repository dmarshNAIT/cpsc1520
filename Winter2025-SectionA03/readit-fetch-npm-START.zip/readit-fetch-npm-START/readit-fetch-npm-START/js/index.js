// import all of our CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/main.css';

// import all of our JS
import './main.js';
// this won't be our standard approach of importing data
// typically we should be importing specific functions, variables, etc